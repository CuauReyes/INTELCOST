<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<?php $this->load->view('includes/plugins'); ?>

<head>
	<meta charset="utf-8">
	<title>Formulario</title>
</head>
<body>

  <div class="contenedor">
    <div class="card rowTitulo">
      <h1>Bienes Intelcost</h1>
    </div>
    <div class="colFiltros">
      <form action="#" method="post" id="formulario">
        <div class="filtrosContenido">
          <div class="tituloFiltros">
            <h5>Filtros</h5>
          </div>
          <div class="filtroCiudad input-field">
            <p><label for="selectCiudad">Ciudad:</label><br></p>
            <select name="ciudad" id="selectCiudad">
              <option value="" selected>Elige una ciudad</option>
            </select>
          </div>
          <div class="filtroTipo input-field">
            <p><label for="selecTipo">Tipo:</label></p>
            <br>
            <select name="tipo" id="selectTipo">
              <option value="">Elige un tipo</option>
            </select>
          </div>
          <div class="filtroPrecio">
            <label for="rangoPrecio">Precio:</label>
            <input type="text" id="rangoPrecio" name="precio" value="" />
          </div>
          <div class="botonField">
            <input type="button" class="btn white" value="Buscar" id="submitButton">
          </div>
        </div>
      </form>
    </div>
    <div id="tabs" style="width: 75%;">
      <ul>
        <li><a href="#tabs-1" id="AllBienes">Bienes disponibles</a></li>
        <li><a href="#tabs-2" id="MisBienes">Mis bienes</a></li>
		<li><a href="#tabs-3" id="MisBienes">Reportes</a></li>
      </ul>
      <div id="tabs-1">
        <div class="colContenido" id="divResultadosBusqueda">
          <div class="tituloContenido card" style="justify-content: center;">
            <h5>Resultados de la búsqueda:</h5>
            <div class="divider" id="resBusqueda"></div>
			<div id="resultado"></div>
          </div>
        </div>
      </div>
      
      <div id="tabs-2" >
        <div class="colContenido" id="divResultadosBusqueda">
          <div class="tituloContenido card" style="justify-content: center;">
            <h5>Bienes guardados:</h5>
            <div class="divider"></div>
			<div id="resultadoMisBienes"></div>
          </div>
        </div>
      </div>

	  <div id="tabs-3">
        <div class="colContenido" id="divResultadosBusqueda">
          <div class="tituloContenido card" style="justify-content: center;">
		  <div class="filtroCiudad input-field">
            <p><label for="selectCiudad">Ciudad:</label><br></p>
            <select name="ciudad" id="selectCiudadExcel">
              <option value="" selected>Elige una ciudad</option>
            </select>
          </div>
          <div class="filtroTipo input-field">
            <p><label for="selecTipo">Tipo:</label></p>
            <br>
            <select name="tipo" id="selectTipoExcel">
              <option value="">Elige un tipo</option>
            </select>
          </div>
		  <div class="botonField">
            <input type="button" class="btn white" value="Descargar" id="submitButtonExcel">
          </div>
          </div>
        </div>
      </div>
    </div>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.11.19/xlsx.full.min.js"></script>
    <script type="text/javascript">
		var base = "<?php echo base_url(); ?>";
		
	/*INICIO DEL DOCUMENTO Y CARGA DE DATOS DE CIUDADES Y TIPOS*/
    $( document ).ready(function() {
		
          $( "#tabs" ).tabs();
		  $.ajax({
                type:'POST',
                url: base+'index.php/BienesController/getCiudades',
				dataType: 'JSON',
                success(data)
                {
					console.log(data);

					$('#selectCiudad').html("");
                    var salida = "<option value=''>Selecciona Ciudad</option>";
                    data.forEach( function(valor, indice, array) {
                        salida += "<option  value="+valor.id+">"+valor.nombre+"</option>";
                    }); 
                    $('#selectCiudad').html(salida);

					$('#selectCiudadExcel').html("");
                    var salida = "<option value=''>Selecciona Ciudad</option>";
                    data.forEach( function(valor, indice, array) {
                        salida += "<option  value="+valor.id+">"+valor.nombre+"</option>";
                    }); 
                    $('#selectCiudadExcel').html(salida);


                }, error(err)
                {
                        hidePreloader(1000);
                        message('Ha sucedido un error, inténtelo de nuevo','error');
                }
    
            });

			$.ajax({
                type:'POST',
                url: base+'index.php/BienesController/getTipos',
				dataType: 'JSON',
                success(data)
                {
					console.log(data);

					$('#selectTipo').html("");
                    var salida = "<option value=''>Selecciona Tipo</option>";
                    data.forEach( function(valor, indice, array) {
                        salida += "<option  value="+valor.id+">"+valor.nombre+"</option>";
                    }); 
                    $('#selectTipo').html(salida);

					$('#selectTipoExcel').html("");
                    var salida = "<option value=''>Selecciona Tipo</option>";
                    data.forEach( function(valor, indice, array) {
                        salida += "<option  value="+valor.id+">"+valor.nombre+"</option>";
                    }); 
                    $('#selectTipoExcel').html(salida);
                }, error(err)
                {
                        hidePreloader(1000);
                        message('Ha sucedido un error, inténtelo de nuevo','error');
                }
    
            });

			$.ajax({
                type:'POST',
                url: base+'index.php/BienesController/getBienesbyFilter',
				dataType: 'JSON',
				data:{
					"ciudad":"",
					"tipo": "",
					"min" : "",
					"max": ""
				},
                success(data)
                {
					console.log(data);
					let resultado = '';
					$('#resultado').html('');
					data.forEach( function(valor, indice, array) {
					resultado += '<div class="row"><div class="col m12"><div class="card"><div class="card-image"><img height="300"  src="<?php echo base_url();?>assets/img/home.jpg"><span class="card-title">Venta</span></div><div class="card-content white-black"><p>Dirección:'+valor.direccion+'</p><p>Ciudad:'+valor.ciudad+'</p><p>Teléfono:'+valor.telefono+'</p><p>Código Postal:'+valor.cp+'</p><p>Tipo:'+valor.tipo+'</p><p>Precio:'+valor.precio+'</p></div><div class="card-action"><a onclick=Guardar('+valor.id+')>Guardar</a></div></div></div></div>';
                    }); 
                    $('#resultado').html(resultado);

                }, error(err)
                {
                        message('Ha sucedido un error, inténtelo de nuevo','error');
                }
    
            });
      });

/*BUSQUEDA */
	  $('#submitButton').click(function()
	  {
		  //alert('Hola');
		  let ciudad = $('#selectCiudad').val();
		  let tipo = $('#selectTipo').val();

		  $.ajax({
                type:'POST',
                url: base+'index.php/BienesController/getBienesbyFilter',
				dataType: 'JSON',
				data:{
					"ciudad":ciudad,
					"tipo": tipo,
					"min" : "",
					"max": ""
				},
                success(data)
                {
					console.log(data);
					let resultado = '';
					$('#resultado').html('');
					data.forEach( function(valor, indice, array) {
					resultado += '<div class="row"><div class="col m12"><div class="card"><div class="card-image"><img height="300"  src="<?php echo base_url();?>assets/img/home.jpg"><span class="card-title">Venta</span></div><div class="card-content white-black"><p>Dirección:'+valor.direccion+'</p><p>Ciudad:'+valor.ciudad+'</p><p>Teléfono:'+valor.telefono+'</p><p>Código Postal:'+valor.cp+'</p><p>Tipo:'+valor.tipo+'</p><p>Precio:'+valor.precio+'</p></div><div class="card-action"><a onclick=Guardar('+valor.id+')>Guardar</a></div></div></div></div>';
                    }); 
                    $('#resultado').html(resultado);

                }, error(err)
                {
                        message('Ha sucedido un error, inténtelo de nuevo','error');
                }
    
            });
	  })
	  function s2ab(s) {
    
	var buf = new ArrayBuffer(s.length);
	var view = new Uint8Array(buf);
	for (var i=0; i<s.length; i++) view[i] = s.charCodeAt(i) & 0xFF;
	return buf;
	
}
	  
/*BOTON DE EXPORTACION DE EXCEL*/
	  $('#submitButtonExcel').click(function()
	  {
		  //alert('Hola');
		  let ciudad = $('#selectCiudadExcel').val();
		  let tipo = $('#selectTipoExcel').val();

		  $.ajax({
                type:'POST',
                url: base+'index.php/BienesController/getBienesbyFilter',
				dataType: 'JSON',
				data:{
					"ciudad":ciudad,
					"tipo": tipo,
					"min" : "",
					"max": ""
				},
                success(data)
                {

					datos = [
                        ['Dirección','Ciudad','Teléfono','Código Postal','Tipo','Precio']
                	];
					data.forEach( function(valor, indice, array) {
					var arr = [valor.direccion,valor.ciudad,valor.telefono,valor.cp,valor.tipo,valor.precio];
					datos.push(arr);
					}); 


					var wb = XLSX.utils.book_new();
                wb.Props = {
                        Title: "Reporte",
                        Subject: "Test",
                        Author: "Cuau Reyes",
                        CreatedDate: new Date(2021,03,15)
                };
                
                wb.SheetNames.push("Busqueda");
                var ws_data = datos;
                var ws = XLSX.utils.aoa_to_sheet(ws_data);
                wb.Sheets["Busqueda"] = ws;
                var wbout = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

                saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), 'Busqueda.xlsx');
                
					

                }, error(err)
                {
                        message('Ha sucedido un error, inténtelo de nuevo','error');
                }
    
            });
	  })

	  /*FUNCION DE GUARDADO DE BIEN */
	  function Guardar(bien)
	  {
		$.ajax({
                type:'POST',
                url: base+'index.php/BienesController/saveBien',
				dataType: 'JSON',
				data:{
					"bien":bien
				},
                success(data)
                {
					if(data == 1)
					{
						Swal.fire(
						'Correcto!',
						'Guardado Correctamente',
						'success'
						);

						refresh();
					}
                }, error(err)
                {
                        message('Ha sucedido un error, inténtelo de nuevo','error');
                }
    
            });
	  }

	  /*FUNCION DE REFRESCO DE DATOS*/
function refresh()
{
	$.ajax({
                type:'POST',
                url: base+'index.php/BienesController/getBienesbyFilter',
				dataType: 'JSON',
				data:{
					"ciudad":"",
					"tipo": "",
					"min" : "",
					"max": ""
				},
                success(data)
                {
					console.log(data);
					let resultado = '';
					$('#resultado').html('');
					data.forEach( function(valor, indice, array) {
					resultado += '<div class="row"><div class="col m12"><div class="card"><div class="card-image"><img height="300"  src="<?php echo base_url();?>assets/img/home.jpg"><span class="card-title">Venta</span></div><div class="card-content white-black"><p>Dirección:'+valor.direccion+'</p><p>Ciudad:'+valor.ciudad+'</p><p>Teléfono:'+valor.telefono+'</p><p>Código Postal:'+valor.cp+'</p><p>Tipo:'+valor.tipo+'</p><p>Precio:'+valor.precio+'</p></div><div class="card-action"><a onclick=Guardar('+valor.id+')>Guardar</a></div></div></div></div>';
                    }); 
                    $('#resultado').html(resultado);

                }, error(err)
                {
                        message('Ha sucedido un error, inténtelo de nuevo','error');
                }
    
            });

			$.ajax({
                type:'POST',
                url: base+'index.php/BienesController/getMisBienesG',
				dataType: 'JSON',
                success(data)
                {
					console.log(data);
					let resultado = '';
					$('#resultadoMisBienes').html('');
					data.forEach( function(valor, indice, array) {
					resultado += '<div class="row"><div class="col m12"><div class="card"><div class="card-image"><img height="300"  src="<?php echo base_url();?>assets/img/home.jpg"><span class="card-title">Venta</span></div><div class="card-content white-black"><p>Dirección:'+valor.direccion+'</p><p>Ciudad:'+valor.ciudad+'</p><p>Teléfono:'+valor.telefono+'</p><p>Código Postal:'+valor.cp+'</p><p>Tipo:'+valor.tipo+'</p><p>Precio:'+valor.precio+'</p></div><div class="card-action"><a onclick=Eliminar('+valor.guardado_id+')>Eliminar</a></div></div></div></div>';
                    }); 
                    $('#resultadoMisBienes').html(resultado);

                }, error(err)
                {
                        message('Ha sucedido un error, inténtelo de nuevo','error');
                }
    
            });
	
}

	/*FUNCION DE REGRESO DE BIENES PROPIOS*/
	  $('#MisBienes').click(function()
	  {
		  $.ajax({
                type:'POST',
                url: base+'index.php/BienesController/getMisBienesG',
				dataType: 'JSON',
                success(data)
                {
					console.log(data);
					let resultado = '';
					$('#resultadoMisBienes').html('');
					data.forEach( function(valor, indice, array) {
					resultado += '<div class="row"><div class="col m12"><div class="card"><div class="card-image"><img height="300"  src="<?php echo base_url();?>assets/img/home.jpg"><span class="card-title">Venta</span></div><div class="card-content white-black"><p>Dirección:'+valor.direccion+'</p><p>Ciudad:'+valor.ciudad+'</p><p>Teléfono:'+valor.telefono+'</p><p>Código Postal:'+valor.cp+'</p><p>Tipo:'+valor.tipo+'</p><p>Precio:'+valor.precio+'</p></div><div class="card-action"><a onclick=Eliminar('+valor.guardado_id+')>Eliminar</a></div></div></div></div>';
                    }); 
                    $('#resultadoMisBienes').html(resultado);

                }, error(err)
                {
                        message('Ha sucedido un error, inténtelo de nuevo','error');
                }
    
            });
	  })

	  /*OBTENCION DE TODOS LOS BIENES*/
	  $('#AllBienes').click(function()
	  {
		$.ajax({
                type:'POST',
                url: base+'index.php/BienesController/getBienesbyFilter',
				dataType: 'JSON',
				data:{
					"ciudad":"",
					"tipo": "",
					"min" : "",
					"max": ""
				},
                success(data)
                {
					console.log(data);
					let resultado = '';
					$('#resultado').html('');
					data.forEach( function(valor, indice, array) {
					resultado += '<div class="row"><div class="col m12"><div class="card"><div class="card-image"><img height="300"  src="<?php echo base_url();?>assets/img/home.jpg"><span class="card-title">Venta</span></div><div class="card-content white-black"><p>Dirección:'+valor.direccion+'</p><p>Ciudad:'+valor.ciudad+'</p><p>Teléfono:'+valor.telefono+'</p><p>Código Postal:'+valor.cp+'</p><p>Tipo:'+valor.tipo+'</p><p>Precio:'+valor.precio+'</p></div><div class="card-action"><a onclick=Guardar('+valor.id+')>Guardar</a></div></div></div></div>';
                    }); 
                    $('#resultado').html(resultado);

                }, error(err)
                {
                        message('Ha sucedido un error, inténtelo de nuevo','error');
                }
    
            });
	  })

	  /*ELIMINACION DE BIENES*/
	  function Eliminar(guardadoID)
	  {
		$.ajax({
                type:'POST',
                url: base+'index.php/BienesController/deleteBienGuardado',
				dataType: 'JSON',
				data:{
					"guardadoID":guardadoID
				},
                success(data)
                {
					if(data == 1)
					{
						Swal.fire(
						'Correcto!',
						'Eliminado Correctamente',
						'success'
						);

						refresh();
					}
                }, error(err)
                {
                        message('Ha sucedido un error, inténtelo de nuevo','error');
                }
            });
	  }

	  
    </script>
  </body>
</html>
