
<!--CARGA DE CDN -->
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/ion.rangeSlider.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/materialize.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/index.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/buscador.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/materialize.min.css"  media="screen,projection"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/customColors.css"  media="screen,projection"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/ion.rangeSlider.css"  media="screen,projection"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/ion.rangeSlider.skinFlat.css"  media="screen,projection"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/index.css"  media="screen,projection"/>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script src="//cdn.jsdelivr.net/npm/promise-polyfill@8/dist/polyfill.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.0/FileSaver.min.js" integrity="sha512-csNcFYJniKjJxRWRV1R7fvnXrycHP6qDR21mgz1ZP55xY5d+aHLfo9/FcGDQLfn2IfngbAHd8LdfsagcCqgTcQ==" crossorigin="anonymous"></script>

