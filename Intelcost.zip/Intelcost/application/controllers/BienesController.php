<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');	

class BienesController extends CI_Controller {
	public function __construct()
	{
			parent::__construct();
			// Your own constructor code
			$this->load->helper('url');
			$this->load->model('Bienes_model');     

	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	/*FUNCION DE OBTENCION DE CIUDADES*/
	public function getCiudades()
	{
		$data = array();
		$queryCiudades = $this->Bienes_model->getAllCiudades();
		foreach($queryCiudades->result() as $row)
		{
			$data [] = array(
				'id' => $row->id,
				'nombre' => utf8_encode($row->nombreCiudad)
			);
		}

		echo json_encode($data);
	}

	/*FUNCION DE OBTENCION DE TIPOS*/
	public function getTipos()
	{
		$data = array();
		$queryCiudades = $this->Bienes_model->getAllTiposBienes();
		foreach($queryCiudades->result() as $row)
		{
			$data [] = array(
				'id' => $row->id,
				'nombre' => utf8_encode($row->nombreTipo)
			);
		}

		echo json_encode($data);
	}

	/*FUNCION DE OBTENCION DE BIENES POR FILTRO*/
	public function getBienesbyFilter()
	{
		$ciudad = $this->input->post('ciudad');
		$tipo = $this->input->post('tipo');
		$precioMin = $this->input->post('min');
		$precioMax = $this->input->post('max');

		$bienes = array();
		$queryBienes = $this->Bienes_model->getBienes($ciudad, $tipo, $precioMin, $precioMax);
		foreach($queryBienes->result() as $row)
		{
			$bienes [] = array(
				'id' => $row->id,
				'direccion' => utf8_encode($row->direccion),
				'ciudad' => utf8_encode($row->nombreCiudad),
				'telefono' => $row->telefono,
				'tipo' => utf8_encode($row->nombreTipo),
				'cp' => $row->cp,
				'precio' => $row->precio
			);
		}

		echo json_encode($bienes);
	}

	/*FUNCION DE GUARDADO DE BIEN */
	public function saveBien()
	{
		$bien = $this->input->post('bien');
		$data = array(
			'motivo' => 'TEST',
			'bien_id' => $bien
		);
		$saveBien = $this->Bienes_model->saveBienG($data);
		if($saveBien)
		{
			echo json_encode(1);
		}else
		{
			echo json_encode(0);
		}
	}

	/*FUNCION OBTENCION DE BIENES PROPIOS */
	public function getMisBienesG()
	{
		$bienes = array();
		$queryMisBienes = $this->Bienes_model->getMisBienes();
		foreach($queryMisBienes->result() as $row)
		{
			$bienes [] = array(
				'guardado_id' => $row->guardadoId,
				'direccion' => utf8_encode($row->direccion),
				'ciudad' => utf8_encode($row->nombreCiudad),
				'telefono' => $row->telefono,
				'tipo' => utf8_encode($row->nombreTipo),
				'cp' => $row->cp,
				'precio' => $row->precio
			);
		}

		echo json_encode($bienes);
	}

		/*FUNCION ELIMINACION DE BIENES PROPIOS */

	public function deleteBienGuardado()
	{
		$bienID =$this->input->post('guardadoID');
		$queryBien = $this->Bienes_model->deleteGuardado($bienID);
		if($queryBien)
		{
			echo json_encode(1);
		}else
		{
			echo json_encode(0);
		}
	}
}
