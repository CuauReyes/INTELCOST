<?php 
class Bienes_model extends CI_Model
{
	/*QUERY DE GET CIUDADES*/
    function getAllCiudades()
    {
        $this->db->select('*');
        $this->db->from('Ciudades');
        $query = $this->db->get();
        return($query);
    }

		/*QUERY DE GET TIPOS DE BIENES*/
	function getAllTiposBienes()
    {
        $this->db->select('*');
        $this->db->from('TiposBienes');
        $query = $this->db->get();
        return($query);
    }

			/*QUERY DE GET BIENES*/

    function getBienes($ciudad, $tipo, $precioMin, $precioMax)
    {
        $this->db->select('*');
        $this->db->from('Bienes as a');
        $this->db->join('TiposBienes as b', 'a.tipo_id = b.id', 'INNER');
		$this->db->join('Ciudades as c', 'a.ciudad_id = c.id', 'INNER');
		if($ciudad)
		{
			$this->db->where('a.ciudad_id', $ciudad);
		}
		if($tipo)
		{ 
			$this->db->where('a.tipo_id', $tipo);
		}

		if($precioMin && $precioMax)
		{
			$this->db->where('a.precio >=', $precioMin);
			$this->db->where('a.precio <=', $precioMax);
		}
        $query = $this->db->get();
        return($query);
    }

	/*QUERY INSERT BIENES*/

	function saveBienG($data)
    {
        $this->db->insert('Guardados', $data);
        if($this->db->affected_rows() > 0)
        {
            return true;
        }else
        {
            return false;
        }
    }

		/*QUERY GET BIENES PROPIOS*/
	function getMisBienes()
	{
		$this->db->select('*');
        $this->db->from('Bienes as a');
        $this->db->join('TiposBienes as b', 'a.tipo_id = b.id', 'INNER');
		$this->db->join('Ciudades as c', 'a.ciudad_id = c.id', 'INNER');
		$this->db->join('Guardados as d', 'a.id = d.bien_id', 'INNER');
        $query = $this->db->get();
        return($query);
	}

		/*QUERY DELETE BIENES*/
	function deleteGuardado($guardadoID)
    {
        $this->db->where('guardadoId', $guardadoID);
        $this->db->delete('Guardados');
        if ($this->db->affected_rows() > '0') {
            return true;
          } 
          else { 
            return false;
        }
    }
}
